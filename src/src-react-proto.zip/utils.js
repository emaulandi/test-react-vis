//const departement_PSN_num = [78,95,92,93,75,76,27,14,50];
const departement_PSN = ['78','95','92','93','75','76','27','14','50'];

export function cleanDataEmploi(data) {

	//console.log(data)
	
  return data.map(row => {
		return {
			x: row.Departement, 
			y: row.Domaine , 
			size: Number(row.Emploi)
		};
			
	});
  
}


export function cleanDataTourisme(data) {
	
	data.forEach( d => {
		//Change , percentage from original data
		d.Hotel_tourisme_perc_residents_etrangers = +d.Hotel_tourisme_perc_residents_etrangers.replace(",",".") ;
		
		//Swith to number
		d.Hotel_tourisme_nb_etablissement = +d.Hotel_tourisme_nb_etablissement;
		d.Hotel_tourisme_total_nuitees_milliers = +d.Hotel_tourisme_total_nuitees_milliers;
		
	});
	
	return data;

}

export function generateItemsScatterplot(data, xAttribute, yAttribute, sizeAttribute) {

	return data.map(row => {
		return {
			x: row[xAttribute], 
			y: row[yAttribute] , 
			size: row[sizeAttribute]
		};
			
	});
}

export function fluxMigratoire(data) {
	
	//console.log(data.features.length);
	var source = [];
	var target = [];

	// La cible est PSN
	var PSN = data.features.filter( d => isPSN(d.properties.code_insee2) );
	//console.log(PSN);
	
	// List of source & target
	PSN.forEach( d => {
		source.push(d.properties.commune1);
		target.push(d.properties.commune2);
		
	});
	
	const uniqueSource = [...new Set(source)]; 
	//console.log(uniqueSource); 
	
	const uniqueTarget = [...new Set(target)]; 
	//console.log(uniqueTarget);
	
	var nodes = [...source, ...target];
	
	var sankeyNodes = nodes.map( (d) => { return {name: d} });

	//console.log(sankeyNodes);
	
	// Generate list of link with unique ID
	var sankeyLinks = PSN.map( (d) => {
		return {
			source: uniqueSource.indexOf(d.properties.commune1) , 
			target: uniqueSource.length + uniqueTarget.indexOf(d.properties.commune2) , 
			value: +d.properties.migration 
		};
	});
	//console.log(sankeyLinks);
	
	return {
		nodes: sankeyNodes, 
		links: sankeyLinks
	};
}

function isPSN(codeCommune) {
	var isPSN = false ;
	var i;
	
	for (i=0; i< departement_PSN.length; i++) {
		if ( codeCommune.indexOf(departement_PSN[i]) === 0) { isPSN = true ; break ;}
	}
	
	// if ( codeCommune.indexOf(departement_PSN[0]) == 0) { isPSN = true ; }
	
	return isPSN;
}


