import React from 'react';
import {XYPlot, XAxis, YAxis, VerticalGridLines, HorizontalGridLines, MarkSeries} from 'react-vis';

export default class ScatterOrdinal extends React.Component {


        render() {
        	return (
		        <XYPlot
				    width={900}
					height={500}
					margin={{left: 200, right: 50, top: 50, bottom: 100}}
					yType="ordinal"
					xType="ordinal">
				
					<VerticalGridLines />
					<HorizontalGridLines />
					<XAxis tickLabelAngle={-30} />
					<YAxis />
				
				  	<MarkSeries
						className="mark-series-example"
						sizeRange={[1, 25]}
						data={this.props.data}

					/>
				</XYPlot>
			);
        }
}

