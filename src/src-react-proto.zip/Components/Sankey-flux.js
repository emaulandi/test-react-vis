import React from 'react';
import SankeyTitle from './../Components/SankeyTitle';

import FluxDepuisPSN from './../data/fluxmigratoire_depuisPSN.json';


export default class SankeyFlux extends React.Component {

	 

	render() {
	
		const std_chartprops = {
	  		height: 400,
	  		width: 800,
	  		margin: {left: 50, right: 10, top: 10, bottom: 10} 
  		};
  	
		return (
			<SankeyTitle data={FluxDepuisPSN} chartprops={std_chartprops} title={{main:"Flux migratoires depuis la vallée de seine", sub: "", p:""}}/>
		);
	}
	
}
