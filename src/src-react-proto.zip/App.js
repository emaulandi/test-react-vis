import React, { Component } from 'react';
import './App.css';


import SankeyFlux from './Components/Sankey-flux';
import ScatterPlotEmploi from './Components/ScatterPlot-emploi';


class App extends Component {
  

  render() {

  	
    return (
		<div className="App">


		<SankeyFlux />
		
		<ScatterPlotEmploi /> 

		</div>

    );
  }
}

export default App;
